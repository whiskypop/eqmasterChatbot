
class GhMsgHandle:
    def __init__(self):
        """
        公众号消息处理
        """
        pass